package com.example.cricify;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HISTORY extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
    }
}
