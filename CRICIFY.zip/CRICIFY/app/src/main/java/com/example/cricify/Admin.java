package com.example.cricify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Admin extends AppCompatActivity {
    static int run = 0;
    static double over1 = 0;
    static double ball = 0;
    static int ballT = 0;
    static double over = 0;
    static int   wicket=0;
    static double crr=0;
    static int batFrun = 0;
    static int batSrun = 0;
    static int batFBall = 0;
    static int batSBall = 0;
    static int batFSix = 0;
    static int batSSix = 0;
    static int batFFour = 0;
    static int batSFour = 0;
    static double batFSR = 0;
    static double batSSR = 0;
    static int bowlrun =0;
    static int bowlwicket =0;
    static int bowlmaiden =0;
    static double bowlover1 = 0;
    static double bowlball = 0;
    static int bowlballT = 0;
    static double bowlover = 0;
    static double bowlER=0;
    static String strike ="*";
    static String nstrike =" ";
    static boolean flag;
    static int pshipr=0;
    static int pshipb=0;
    static  int count;
    static int one;
    static String ones;
    static int inning;
    static String teamName;
    static String hostname1;
    static String vistorname1;
    static String inputOver2;
    static double inputOver;
    static String h1;
    static String h2;
    static String h3;
    static String h4;
    static String h5;
    static String h6;
    static String h7;
    static String h8;
    static String h9;
    static String h10;
    static String h11;
    static String v1;
    static String v2;
    static String v3;
    static String v4;
    static String v5;
    static String v6;
    static String v7;
    static String v8;
    static String v9;
    static String v10;
    static String v11;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        Intent i=getIntent();
        hostname1=i.getStringExtra("HT");
        vistorname1=i.getStringExtra("VT");
        inputOver2=i.getStringExtra("O");
        inputOver=Double.parseDouble(inputOver2);
        h1=i.getStringExtra("H1");
        h2=i.getStringExtra("H2");
        h3=i.getStringExtra("H3");
        h4=i.getStringExtra("H4");
        h5=i.getStringExtra("H5");
        h6=i.getStringExtra("H6");
        h7=i.getStringExtra("H7");
        h8=i.getStringExtra("H8");
        h9=i.getStringExtra("H9");
        h10=i.getStringExtra("H10");
        h11=i.getStringExtra("H11");
        v1=i.getStringExtra("V1");
        v2=i.getStringExtra("V2");
        v3=i.getStringExtra("V3");
        v4=i.getStringExtra("V4");
        v5=i.getStringExtra("V5");
        v6=i.getStringExtra("V6");
        v7=i.getStringExtra("V7");
        v8=i.getStringExtra("V8");
        v9=i.getStringExtra("V9");
        v10=i.getStringExtra("V10");
        v11=i.getStringExtra("V11");




        Button startBtn = (Button) findViewById(R.id.ButtonContinue);
        startBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {



                    TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                    TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                    TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                    TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                    TextView tV_FBatStrike = (TextView) findViewById(R.id.tVFBatStrike);
                    TextView tV_SBatStrike = (TextView) findViewById(R.id.tVSBatStrike);
                    TextView tV_FBatRun = (TextView) findViewById(R.id.tVFBatRun);
                    TextView tV_SBatRun = (TextView) findViewById(R.id.tVSBatRun);
                    TextView tV_FBatBall = (TextView) findViewById(R.id.tVFBatBall);
                    TextView tV_SBatBall = (TextView) findViewById(R.id.tVSBatBall);
                    TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                    TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                    TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                    TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                    TextView tV_FBatSR = (TextView) findViewById(R.id.tVFBatSR);
                    TextView tV_SBatSR = (TextView) findViewById(R.id.tVSBatSR);
                    TextView tV_BowlOvers = (TextView) findViewById(R.id.tVBowlOvers);
                    TextView tV_BowlMaiden = (TextView) findViewById(R.id.tVBowlMaiden);
                    TextView tV_BowlRun = (TextView) findViewById(R.id.tVBowlRun);
                    TextView tV_BowlWicket = (TextView) findViewById(R.id.tVBowlWicket);
                    TextView tV_BowlER = (TextView) findViewById(R.id.tVBowlER);
                    TextView tV_Pshipr = (TextView) findViewById(R.id.tVPshipR);
                    TextView tV_Pshipb = (TextView) findViewById(R.id.tVPshipB);
                    TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                    TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);
                    TextView tV_ThisOver1=(TextView) findViewById(R.id.tVThisOver1);
                    TextView tV_ThisOver2=(TextView) findViewById(R.id.tVThisOver2);
                    TextView tV_ThisOver3=(TextView) findViewById(R.id.tVThisOver3);
                    TextView tV_ThisOver4=(TextView) findViewById(R.id.tVThisOver4);
                    TextView tV_ThisOver5=(TextView) findViewById(R.id.tVThisOver5);
                    TextView tV_ThisOver6=(TextView) findViewById(R.id.tVThisOver6);
                    TextView tV_ThisOver7=(TextView) findViewById(R.id.tVThisOver7);
                    TextView tV_ThisOver8=(TextView) findViewById(R.id.tVThisOver8);
                    TextView tV_ThisOver9=(TextView) findViewById(R.id.tVThisOver9);

                    tV_FBatStrike.setText(strike);
                    flag = true;
                    count = 0;
                    inning = 1;
                    tV_Teamname.setText(hostname1);

                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_FBatRun.setText(Integer.toString(batFrun));
                    tV_FBatBall.setText(Integer.toString(batFBall));
                    tV_FBatFour.setText(Integer.toString(batFSix));
                    tV_FBatSix.setText(Integer.toString(batFFour));
                    tV_FBatSR.setText(Double.toString(batFSR));
                    tV_SBatRun.setText(Integer.toString(batSrun));
                    tV_SBatBall.setText(Integer.toString(batSBall));
                    tV_SBatFour.setText(Integer.toString(batSSix));
                    tV_SBatSix.setText(Integer.toString(batSFour));
                    tV_SBatSR.setText(Double.toString(batSSR));
                    tV_BowlOvers.setText(Double.toString(bowlover));
                    tV_BowlMaiden.setText(Integer.toString(bowlmaiden));
                    tV_BowlRun.setText(Integer.toString(bowlrun));
                    tV_BowlWicket.setText(Integer.toString(bowlwicket));
                    tV_BowlER.setText(Double.toString(bowlER));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));
                    tV_Inning.setText(Integer.toString(inning));



            }
        });

        Button oneBtn = (Button) findViewById(R.id.ButtonRun1);
        oneBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatStrike = (TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatStrike = (TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun = (TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun = (TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall = (TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall = (TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR = (TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR = (TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers = (TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden = (TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun = (TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket = (TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER = (TextView) findViewById(R.id.tVBowlER);
                TextView tV_Pshipr = (TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb = (TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1 = (TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2 = (TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3 = (TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4 = (TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5 = (TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6 = (TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7 = (TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8 = (TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9 = (TextView) findViewById(R.id.tVThisOver9);
                TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);

                if (over != inputOver)
                {
                    if (count ==0 || count == 9) {

                        count=0;
                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                    }
                    one = 1;
                    run += 1;
                    ball += 0.1;
                    count += 1;
                    ballT += 1;
                    if (ball == 0.6) {
                        over1 += 1;
                        ball = 0;

                    }
                    over = over1 + ball;
                    crr = 6.0 * run / ballT;

                    bowlball += 0.1;
                    bowlballT += 1;
                    bowlrun += 1;

                    if (bowlball == 0.6) {
                        bowlover1 += 1;
                        bowlball = 0;
                    }
                    bowlover = bowlover1 + bowlball;
                    bowlER = 6.0 * run / ballT;

                    if (flag == true) {
                        batFrun += 1;
                        batFBall += 1;
                        batFSR = 100 * batFrun / batFBall;
                    } else {
                        batSrun += 1;
                        batSBall += 1;
                        batSSR = 100 * batSrun / batSBall;
                    }
                    pshipr = batFrun + batSrun;
                    pshipb = batFBall + batSBall;

                    switch (count)
                    {
                        case 1:
                            tV_ThisOver1.setText(Integer.toString(one));
                            break;
                        case 2:
                            tV_ThisOver2.setText(Integer.toString(one));
                            break;
                        case 3:
                            tV_ThisOver3.setText(Integer.toString(one));
                            break;
                        case 4:
                            tV_ThisOver4.setText(Integer.toString(one));
                            break;
                        case 5:
                            tV_ThisOver5.setText(Integer.toString(one));
                            break;
                        case 6:
                            tV_ThisOver6.setText(Integer.toString(one));
                            break;
                        case 7:
                            tV_ThisOver7.setText(Integer.toString(one));
                            break;
                        case 8:
                            tV_ThisOver8.setText(Integer.toString(one));
                            break;
                        case 9:
                            tV_ThisOver9.setText(Integer.toString(one));
                            break;

                    }
                    if(ball==0)
                    {
                        count=0;
                    }

                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_FBatRun.setText(Integer.toString(batFrun));
                    tV_FBatBall.setText(Integer.toString(batFBall));
                    tV_FBatSR.setText(Double.toString(batFSR));
                    tV_SBatRun.setText(Integer.toString(batSrun));
                    tV_SBatBall.setText(Integer.toString(batSBall));
                    tV_SBatSR.setText(Double.toString(batSSR));
                    tV_BowlOvers.setText(Double.toString(bowlover));
                    tV_BowlMaiden.setText(Integer.toString(bowlmaiden));
                    tV_BowlRun.setText(Integer.toString(bowlrun));
                    tV_BowlWicket.setText(Integer.toString(bowlwicket));
                    tV_BowlER.setText(Double.toString(bowlER));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));

                }
                else
                {
                    Toast.makeText(Admin.this,"1st INNING OVER",Toast.LENGTH_LONG).show();
                    inning=2;
                    run =0;
                    ball =0;
                    over =0;
                    over1 =0;
                    crr =0;
                    wicket =0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun =0;
                    bowlwicket =0;
                    bowlmaiden =0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER=0;
                    strike ="*";
                    nstrike =" ";
                    flag=true;
                    pshipr=0;
                    pshipb=0;
                    count=0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
            }

        });

        Button twoBtn = (Button) findViewById(R.id.ButtonRun2);
        twoBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent = (TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent = (TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun = (TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun = (TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall = (TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall = (TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR = (TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR = (TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers = (TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden = (TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun = (TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket = (TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER = (TextView) findViewById(R.id.tVBowlER);
                TextView tV_Pshipr = (TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb = (TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1 = (TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2 = (TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3 = (TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4 = (TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5 = (TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6 = (TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7 = (TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8 = (TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9 = (TextView) findViewById(R.id.tVThisOver9);
                TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);

                if (over != inputOver)
                {

                    if (count == 0 || count == 9)
                    {
                        count=0;
                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                    }

                    one = 2;
                    run += 2;
                    ball += 0.1;
                    count += 1;
                    ballT += 1;
                    if (ball == 0.6) {
                        over1 += 1;
                        ball = 0;
                    }
                    over = over1 + ball;
                    crr = 6.0 * run / ballT;
                    bowlball += 0.1;
                    bowlballT += 1;
                    bowlrun += 2;

                    if (bowlball == 0.6) {
                        bowlover1 += 1;
                        bowlball = 0;
                    }
                    bowlover = bowlover1 + bowlball;
                    bowlER = 6.0 * run / ballT;
                    if (flag == true) {
                        batFrun += 2;
                        batFBall += 1;
                        batFSR = 100 * batFrun / batFBall;
                    } else {
                        batSrun += 2;
                        batSBall += 1;
                        batSSR = 100 * batSrun / batSBall;
                    }
                    pshipr = batFrun + batSrun;
                    pshipb = batFBall + batSBall;
                    switch (count) {
                        case 1:
                            tV_ThisOver1.setText(Integer.toString(one));
                            break;
                        case 2:
                            tV_ThisOver2.setText(Integer.toString(one));
                            break;
                        case 3:
                            tV_ThisOver3.setText(Integer.toString(one));
                            break;
                        case 4:
                            tV_ThisOver4.setText(Integer.toString(one));
                            break;
                        case 5:
                            tV_ThisOver5.setText(Integer.toString(one));
                            break;
                        case 6:
                            tV_ThisOver6.setText(Integer.toString(one));
                            break;
                        case 7:
                            tV_ThisOver7.setText(Integer.toString(one));
                            break;
                        case 8:
                            tV_ThisOver8.setText(Integer.toString(one));
                            break;
                        case 9:
                            tV_ThisOver9.setText(Integer.toString(one));
                            break;

                    }
                    if(ball==0)
                    {
                        count=0;
                    }


                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_FBatRun.setText(Integer.toString(batFrun));
                    tV_FBatBall.setText(Integer.toString(batFBall));
                    tV_FBatSR.setText(Double.toString(batFSR));
                    tV_SBatRun.setText(Integer.toString(batSrun));
                    tV_SBatBall.setText(Integer.toString(batSBall));
                    tV_SBatSR.setText(Double.toString(batSSR));
                    tV_BowlOvers.setText(Double.toString(bowlover));
                    tV_BowlMaiden.setText(Integer.toString(bowlmaiden));
                    tV_BowlRun.setText(Integer.toString(bowlrun));
                    tV_BowlWicket.setText(Integer.toString(bowlwicket));
                    tV_BowlER.setText(Double.toString(bowlER));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));


                }
                else
                {
                    Toast.makeText(Admin.this,"1st INNING OVER",Toast.LENGTH_LONG).show();
                    inning=2;
                    run =0;
                    ball =0;
                    over =0;
                    over1 =0;
                    crr =0;
                    wicket =0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun =0;
                    bowlwicket =0;
                    bowlmaiden =0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER=0;
                    strike ="*";
                    nstrike =" ";
                    flag=true;
                    pshipr=0;
                    pshipb=0;
                    count=0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
            }

        });


        Button threeBtn = (Button) findViewById(R.id.ButtonRun3);
        threeBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent = (TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent = (TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun = (TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun = (TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall = (TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall = (TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR = (TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR = (TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers = (TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden = (TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun = (TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket = (TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER = (TextView) findViewById(R.id.tVBowlER);
                TextView tV_Pshipr = (TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb = (TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1 = (TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2 = (TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3 = (TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4 = (TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5 = (TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6 = (TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7 = (TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8 = (TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9 = (TextView) findViewById(R.id.tVThisOver9);
                TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);

                if (over != inputOver) {

                    if (count == 0 || count == 9)
                    {
                        count=0;

                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                    }

                    one = 3;
                    run += 3;
                    ball += 0.1;
                    count += 1;
                    ballT += 1;
                    if (ball == 0.6) {
                        over1 += 1;
                        ball = 0;
                    }
                    over = over1 + ball;
                    crr = 6.0 * run / ballT;
                    bowlball += 0.1;
                    bowlballT += 1;
                    bowlrun += 3;

                    if (bowlball == 0.6) {
                        bowlover1 += 1;
                        bowlball = 0;
                    }
                    bowlover = bowlover1 + bowlball;
                    bowlER = 6.0 * run / ballT;
                    if (flag == true) {
                        batFrun += 3;
                        batFBall += 1;
                        batFSR = 100 * batFrun / batFBall;
                    } else {
                        batSrun += 3;
                        batSBall += 1;
                        batSSR = 100 * batSrun / batSBall;
                    }
                    pshipr = batFrun + batSrun;
                    pshipb = batFBall + batSBall;
                    switch (count) {
                        case 1:
                            tV_ThisOver1.setText(Integer.toString(one));
                            break;
                        case 2:
                            tV_ThisOver2.setText(Integer.toString(one));
                            break;
                        case 3:
                            tV_ThisOver3.setText(Integer.toString(one));
                            break;
                        case 4:
                            tV_ThisOver4.setText(Integer.toString(one));
                            break;
                        case 5:
                            tV_ThisOver5.setText(Integer.toString(one));
                            break;
                        case 6:
                            tV_ThisOver6.setText(Integer.toString(one));
                            break;
                        case 7:
                            tV_ThisOver7.setText(Integer.toString(one));
                            break;
                        case 8:
                            tV_ThisOver8.setText(Integer.toString(one));
                            break;
                        case 9:
                            tV_ThisOver9.setText(Integer.toString(one));
                            break;

                    }
                    if(ball==0)
                    {
                        count=0;
                    }


                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_FBatRun.setText(Integer.toString(batFrun));
                    tV_FBatBall.setText(Integer.toString(batFBall));
                    tV_FBatSR.setText(Double.toString(batFSR));
                    tV_SBatRun.setText(Integer.toString(batSrun));
                    tV_SBatBall.setText(Integer.toString(batSBall));
                    tV_SBatSR.setText(Double.toString(batSSR));
                    tV_BowlOvers.setText(Double.toString(bowlover));
                    tV_BowlMaiden.setText(Integer.toString(bowlmaiden));
                    tV_BowlRun.setText(Integer.toString(bowlrun));
                    tV_BowlWicket.setText(Integer.toString(bowlwicket));
                    tV_BowlER.setText(Double.toString(bowlER));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));


                } else {
                    Toast.makeText(Admin.this,"1st INNING OVER",Toast.LENGTH_LONG).show();
                    inning = 2;
                    run = 0;
                    ball = 0;
                    over = 0;
                    over1 = 0;
                    crr = 0;
                    wicket = 0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun = 0;
                    bowlwicket = 0;
                    bowlmaiden = 0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER = 0;
                    strike = "*";
                    nstrike = " ";
                    flag = true;
                    pshipr = 0;
                    pshipb = 0;
                    count = 0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
            }
        });

        Button fourBtn = (Button) findViewById(R.id.ButtonRun4);
        fourBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent = (TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent = (TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun = (TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun = (TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall = (TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall = (TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSR = (TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR = (TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers = (TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden = (TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun = (TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket = (TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER = (TextView) findViewById(R.id.tVBowlER);
                TextView tV_Pshipr = (TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb = (TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1 = (TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2 = (TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3 = (TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4 = (TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5 = (TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6 = (TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7 = (TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8 = (TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9 = (TextView) findViewById(R.id.tVThisOver9);
                TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);

                if (over != inputOver) {
                    if (count == 0 || count == 9)
                    {
                        count=0;

                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                    }

                    one = 4;
                    run += 4;
                    ball += 0.1;
                    count += 1;
                    ballT += 1;
                    if (ball == 0.6) {
                        over1 += 1;
                        ball = 0;
                    }
                    over = over1 + ball;
                    crr = 6.0 * run / ballT;
                    bowlball += 0.1;
                    bowlballT += 1;
                    bowlrun += 4;

                    if (bowlball == 0.6) {
                        bowlover1 += 1;
                        bowlball = 0;
                    }
                    bowlover = bowlover1 + bowlball;
                    bowlER = 6.0 * run / ballT;
                    if (flag == true) {
                        batFrun += 4;
                        batFBall += 1;
                        batFFour += 1;
                        batFSR = 100 * batFrun / batFBall;
                    } else {
                        batSrun += 4;
                        batSBall += 1;
                        batSFour += 1;
                        batSSR = 100 * batSrun / batSBall;
                    }
                    pshipr = batFrun + batSrun;
                    pshipb = batFBall + batSBall;
                    switch (count) {
                        case 1:
                            tV_ThisOver1.setText(Integer.toString(one));
                            break;
                        case 2:
                            tV_ThisOver2.setText(Integer.toString(one));
                            break;
                        case 3:
                            tV_ThisOver3.setText(Integer.toString(one));
                            break;
                        case 4:
                            tV_ThisOver4.setText(Integer.toString(one));
                            break;
                        case 5:
                            tV_ThisOver5.setText(Integer.toString(one));
                            break;
                        case 6:
                            tV_ThisOver6.setText(Integer.toString(one));
                            break;
                        case 7:
                            tV_ThisOver7.setText(Integer.toString(one));
                            break;
                        case 8:
                            tV_ThisOver8.setText(Integer.toString(one));
                            break;
                        case 9:
                            tV_ThisOver9.setText(Integer.toString(one));
                            break;

                    }
                    if(ball==0)
                    {
                        count=0;
                    }


                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_FBatRun.setText(Integer.toString(batFrun));
                    tV_FBatBall.setText(Integer.toString(batFBall));
                    tV_FBatFour.setText(Integer.toString(batFFour));
                    tV_FBatSR.setText(Double.toString(batFSR));
                    tV_SBatRun.setText(Integer.toString(batSrun));
                    tV_SBatBall.setText(Integer.toString(batSBall));
                    tV_SBatFour.setText(Integer.toString(batSFour));
                    tV_SBatSR.setText(Double.toString(batSSR));
                    tV_BowlOvers.setText(Double.toString(bowlover));
                    tV_BowlMaiden.setText(Integer.toString(bowlmaiden));
                    tV_BowlRun.setText(Integer.toString(bowlrun));
                    tV_BowlWicket.setText(Integer.toString(bowlwicket));
                    tV_BowlER.setText(Double.toString(bowlER));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));


                } else {
                    Toast.makeText(Admin.this,"1st INNING OVER",Toast.LENGTH_LONG).show();
                    inning = 2;
                    run = 0;
                    ball = 0;
                    over = 0;
                    over1 = 0;
                    crr = 0;
                    wicket = 0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun = 0;
                    bowlwicket = 0;
                    bowlmaiden = 0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER = 0;
                    strike = "*";
                    nstrike = " ";
                    flag = true;
                    pshipr = 0;
                    pshipb = 0;
                    count = 0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
            }
        });

        Button sixBtn = (Button) findViewById(R.id.ButtonRun6);
        sixBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent = (TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent = (TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun = (TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun = (TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                TextView tV_FBatBall = (TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall = (TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR = (TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR = (TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers = (TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden = (TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun = (TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket = (TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER = (TextView) findViewById(R.id.tVBowlER);
                TextView tV_Pshipr = (TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb = (TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1 = (TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2 = (TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3 = (TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4 = (TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5 = (TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6 = (TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7 = (TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8 = (TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9 = (TextView) findViewById(R.id.tVThisOver9);
                TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);

                if (over != inputOver) {

                    if (count == 0 || count == 9)
                    {
                        count=0;

                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                    }

                    one = 6;
                    run += 6;
                    ball += 0.1;
                    count += 1;
                    ballT += 1;
                    if (ball == 0.6) {
                        over1 += 1;
                        ball = 0;
                    }
                    over = over1 + ball;
                    crr = 6.0 * run / ballT;
                    bowlball += 0.1;
                    bowlballT += 1;
                    bowlrun += 6;

                    if (bowlball == 0.6) {
                        bowlover1 += 1;
                        bowlball = 0;
                    }
                    bowlover = bowlover1 + bowlball;
                    bowlER = 6.0 * run / ballT;
                    if (flag == true) {
                        batFrun += 6;
                        batFBall += 1;
                        batFSix += 1;
                        batFSR = 100 * batFrun / batFBall;
                    } else {
                        batSrun += 6;
                        batSBall += 1;
                        batSSix += 1;
                        batSSR = 100 * batSrun / batSBall;
                    }
                    pshipr = batFrun + batSrun;
                    pshipb = batFBall + batSBall;
                    switch (count) {
                        case 1:
                            tV_ThisOver1.setText(Integer.toString(one));
                            break;
                        case 2:
                            tV_ThisOver2.setText(Integer.toString(one));
                            break;
                        case 3:
                            tV_ThisOver3.setText(Integer.toString(one));
                            break;
                        case 4:
                            tV_ThisOver4.setText(Integer.toString(one));
                            break;
                        case 5:
                            tV_ThisOver5.setText(Integer.toString(one));
                            break;
                        case 6:
                            tV_ThisOver6.setText(Integer.toString(one));
                            break;
                        case 7:
                            tV_ThisOver7.setText(Integer.toString(one));
                            break;
                        case 8:
                            tV_ThisOver8.setText(Integer.toString(one));
                            break;
                        case 9:
                            tV_ThisOver9.setText(Integer.toString(one));
                            break;

                    }
                    if(ball==0)
                    {
                        count=0;
                    }

                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_FBatRun.setText(Integer.toString(batFrun));
                    tV_FBatBall.setText(Integer.toString(batFBall));
                    tV_FBatSix.setText(Integer.toString(batFSix));
                    tV_FBatSR.setText(Double.toString(batFSR));
                    tV_SBatRun.setText(Integer.toString(batSrun));
                    tV_SBatBall.setText(Integer.toString(batSBall));
                    tV_SBatSix.setText(Integer.toString(batSSix));
                    tV_SBatSR.setText(Double.toString(batSSR));
                    tV_BowlOvers.setText(Double.toString(bowlover));
                    tV_BowlMaiden.setText(Integer.toString(bowlmaiden));
                    tV_BowlRun.setText(Integer.toString(bowlrun));
                    tV_BowlWicket.setText(Integer.toString(bowlwicket));
                    tV_BowlER.setText(Double.toString(bowlER));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));


                } else {
                    Toast.makeText(Admin.this,"1st INNING OVER",Toast.LENGTH_LONG).show();
                    inning = 2;
                    run = 0;
                    ball = 0;
                    over = 0;
                    over1 = 0;
                    crr = 0;
                    wicket = 0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun = 0;
                    bowlwicket = 0;
                    bowlmaiden = 0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER = 0;
                    strike = "*";
                    nstrike = " ";
                    flag = true;
                    pshipr = 0;
                    pshipb = 0;
                    count = 0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
            }
        });

        Button fiveBtn = (Button) findViewById(R.id.ButtonRun5);
        fiveBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent = (TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent = (TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun = (TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun = (TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall = (TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall = (TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR = (TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR = (TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers = (TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden = (TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun = (TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket = (TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER = (TextView) findViewById(R.id.tVBowlER);
                TextView tV_Pshipr = (TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb = (TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1 = (TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2 = (TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3 = (TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4 = (TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5 = (TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6 = (TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7 = (TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8 = (TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9 = (TextView) findViewById(R.id.tVThisOver9);
                TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);

                if (over != inputOver) {
                    if (count == 0 || count == 9)
                    {
                        count=0;

                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                    }

                    one = 5;
                    run += 5;
                    ball += 0.1;
                    count += 1;
                    ballT += 1;
                    if (ball == 0.6) {
                        over1 += 1;
                        ball = 0;
                    }
                    over = over1 + ball;
                    crr = 6.0 * run / ballT;
                    bowlball += 0.1;
                    bowlballT += 1;
                    bowlrun += 5;

                    if (bowlball == 0.6) {
                        bowlover1 += 1;
                        bowlball = 0;
                    }
                    bowlover = bowlover1 + bowlball;
                    bowlER = 6.0 * run / ballT;
                    if (flag == true) {
                        batFrun += 5;
                        batFBall += 1;
                        batFSR = 100 * batFrun / batFBall;
                    } else {
                        batSrun += 5;
                        batSBall += 1;
                        batSSR = 100 * batSrun / batSBall;
                    }
                    pshipr = batFrun + batSrun;
                    pshipb = batFBall + batSBall;
                    switch (count) {
                        case 1:
                            tV_ThisOver1.setText(Integer.toString(one));
                            break;
                        case 2:
                            tV_ThisOver2.setText(Integer.toString(one));
                            break;
                        case 3:
                            tV_ThisOver3.setText(Integer.toString(one));
                            break;
                        case 4:
                            tV_ThisOver4.setText(Integer.toString(one));
                            break;
                        case 5:
                            tV_ThisOver5.setText(Integer.toString(one));
                            break;
                        case 6:
                            tV_ThisOver6.setText(Integer.toString(one));
                            break;
                        case 7:
                            tV_ThisOver7.setText(Integer.toString(one));
                            break;
                        case 8:
                            tV_ThisOver8.setText(Integer.toString(one));
                            break;
                        case 9:
                            tV_ThisOver9.setText(Integer.toString(one));
                            break;

                    }
                    if(ball==0)
                    {
                        count=0;
                    }


                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_FBatRun.setText(Integer.toString(batFrun));
                    tV_FBatBall.setText(Integer.toString(batFBall));
                    tV_FBatSR.setText(Double.toString(batFSR));
                    tV_SBatRun.setText(Integer.toString(batSrun));
                    tV_SBatBall.setText(Integer.toString(batSBall));
                    tV_SBatSR.setText(Double.toString(batSSR));
                    tV_BowlOvers.setText(Double.toString(bowlover));
                    tV_BowlMaiden.setText(Integer.toString(bowlmaiden));
                    tV_BowlRun.setText(Integer.toString(bowlrun));
                    tV_BowlWicket.setText(Integer.toString(bowlwicket));
                    tV_BowlER.setText(Double.toString(bowlER));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));


                } else {
                    Toast.makeText(Admin.this,"1st INNING OVER",Toast.LENGTH_LONG).show();
                    inning = 2;
                    run = 0;
                    ball = 0;
                    over = 0;
                    over1 = 0;
                    crr = 0;
                    wicket = 0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun = 0;
                    bowlwicket = 0;
                    bowlmaiden = 0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER = 0;
                    strike = "*";
                    nstrike = " ";
                    flag = true;
                    pshipr = 0;
                    pshipb = 0;
                    count = 0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
            }
        });


        Button wideBtn = (Button) findViewById(R.id.ButtonWide);
        wideBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent = (TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent = (TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun = (TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun = (TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall = (TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall = (TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR = (TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR = (TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers = (TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden = (TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun = (TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket = (TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER = (TextView) findViewById(R.id.tVBowlER);
                TextView tV_Pshipr = (TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb = (TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1 = (TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2 = (TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3 = (TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4 = (TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5 = (TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6 = (TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7 = (TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8 = (TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9 = (TextView) findViewById(R.id.tVThisOver9);
                TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);


                if (over != inputOver) {
                    if (count ==0 || count == 9) {

                        count=0;
                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                    }

                    ones = "W'";
                    count += 1;
                    run += 1;
                    over = over1 + ball;
                    crr = 6.0 * run / ballT;
                    bowlrun += 1;
                    pshipr += 1;
                    switch (count) {
                        case 1:
                            tV_ThisOver1.setText(ones);
                            break;
                        case 2:
                            tV_ThisOver2.setText(ones);
                            break;
                        case 3:
                            tV_ThisOver3.setText(ones);
                            break;
                        case 4:
                            tV_ThisOver4.setText(ones);
                            break;
                        case 5:
                            tV_ThisOver5.setText(ones);
                            break;
                        case 6:
                            tV_ThisOver6.setText(ones);
                            break;
                        case 7:
                            tV_ThisOver7.setText(ones);
                            break;
                        case 8:
                            tV_ThisOver8.setText(ones);
                            break;
                        case 9:
                            tV_ThisOver9.setText(ones);
                            break;

                    }

                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_BowlRun.setText(Integer.toString(bowlrun));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));


                } else {
                    Toast.makeText(Admin.this,"1st INNING OVER",Toast.LENGTH_LONG).show();
                    inning = 2;
                    run = 0;
                    ball = 0;
                    over = 0;
                    over1 = 0;
                    crr = 0;
                    wicket = 0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun = 0;
                    bowlwicket = 0;
                    bowlmaiden = 0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER = 0;
                    strike = "*";
                    nstrike = " ";
                    flag = true;
                    pshipr = 0;
                    pshipb = 0;
                    count = 0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
            }
        });


        Button dotBtn = (Button) findViewById(R.id.ButtonDot);
        dotBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent = (TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent = (TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun = (TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun = (TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall = (TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall = (TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR = (TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR = (TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers = (TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden = (TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun = (TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket = (TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER = (TextView) findViewById(R.id.tVBowlER);
                TextView tV_Pshipr = (TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb = (TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1 = (TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2 = (TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3 = (TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4 = (TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5 = (TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6 = (TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7 = (TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8 = (TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9 = (TextView) findViewById(R.id.tVThisOver9);
                TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);

                if (over != inputOver) {
                    if (count == 0 || count == 9) {
                        count=0;

                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                    }

                    ones = "-";
                    ball += 0.1;
                    ballT += 1;
                    count += 1;
                    if (ball == 0.6) {
                        over1 += 1;
                        ball = 0;
                    }
                    over = over1 + ball;
                    crr = 6.0 * run / ballT;
                    bowlball += 0.1;
                    bowlballT += 1;


                    if (bowlball == 0.6) {
                        bowlover1 += 1;
                        bowlball = 0;
                    }
                    bowlover = bowlover1 + bowlball;
                    bowlER = 6.0 * run / ballT;
                    if (flag == true) {

                        batFBall += 1;
                        batFSR = 100 * batFrun / batFBall;
                    } else {

                        batSBall += 1;
                        batSSR = 100 * batSrun / batSBall;
                    }

                    pshipb += 1;
                    switch (count) {
                        case 1:
                            tV_ThisOver1.setText(ones);
                            break;
                        case 2:
                            tV_ThisOver2.setText(ones);
                            break;
                        case 3:
                            tV_ThisOver3.setText(ones);
                            break;
                        case 4:
                            tV_ThisOver4.setText(ones);
                            break;
                        case 5:
                            tV_ThisOver5.setText(ones);
                            break;
                        case 6:
                            tV_ThisOver6.setText(ones);
                            break;
                        case 7:
                            tV_ThisOver7.setText(ones);
                            break;
                        case 8:
                            tV_ThisOver8.setText(ones);
                            break;
                        case 9:
                            tV_ThisOver9.setText(ones);
                            break;

                    }
                    if(ball==0)
                    {
                        count=0;
                    }

                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_FBatRun.setText(Integer.toString(batFrun));
                    tV_FBatBall.setText(Integer.toString(batFBall));
                    tV_FBatSR.setText(Double.toString(batFSR));
                    tV_SBatRun.setText(Integer.toString(batSrun));
                    tV_SBatBall.setText(Integer.toString(batSBall));
                    tV_SBatSR.setText(Double.toString(batSSR));
                    tV_BowlOvers.setText(Double.toString(bowlover));
                    tV_BowlMaiden.setText(Integer.toString(bowlmaiden));
                    tV_BowlRun.setText(Integer.toString(bowlrun));
                    tV_BowlWicket.setText(Integer.toString(bowlwicket));
                    tV_BowlER.setText(Double.toString(bowlER));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));


                } else {
                    Toast.makeText(Admin.this,"1st INNING OVER",Toast.LENGTH_LONG).show();
                    inning = 2;
                    run = 0;
                    ball = 0;
                    over = 0;
                    over1 = 0;
                    crr = 0;
                    wicket = 0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun = 0;
                    bowlwicket = 0;
                    bowlmaiden = 0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER = 0;
                    strike = "*";
                    nstrike = " ";
                    flag = true;
                    pshipr = 0;
                    pshipb = 0;
                    count = 0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
            }
        });


        Button wicketBtn = (Button) findViewById(R.id.ButtonWicket);
        wicketBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent = (TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent = (TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun = (TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun = (TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall = (TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall = (TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR = (TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR = (TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers = (TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden = (TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun = (TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket = (TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER = (TextView) findViewById(R.id.tVBowlER);
                TextView tV_Pshipr = (TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb = (TextView) findViewById(R.id.tVPshipB);
                TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                TextView tV_ThisOver1 = (TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2 = (TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3 = (TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4 = (TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5 = (TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6 = (TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7 = (TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8 = (TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9 = (TextView) findViewById(R.id.tVThisOver9);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);
                if (over != inputOver) {

                    if (count == 0 || count == 9) {
                        count=0;
                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                    }

                    ones = "W";
                    count += 1;
                    wicket += 1;
                    if (wicket == 10) {

                    }
                    ball += 0.1;
                    ballT += 1;
                    if (ball == 0.6) {
                        over1 += 1;
                        ball = 0;
                    }
                    over = over1 + ball;
                    crr = 6.0 * run / ballT;
                    bowlball += 0.1;
                    bowlballT += 1;


                    if (bowlball == 0.6) {
                        bowlover1 += 1;
                        bowlball = 0;
                    }
                    bowlover = bowlover1 + bowlball;
                    bowlER = 6.0 * run / ballT;
                    bowlwicket += 1;
                    if (flag == true) {
                        batFrun =0;
                        batFBall = 0;
                        batFSix=0;
                        batFFour=0;
                        batFSR = 0;
                    } else {
                        batSrun =0;
                        batSBall =0;
                        batFSix=0;
                        batSFour=0;
                        batSSR = 0;
                    }
                    pshipr = 0;
                    pshipb = 0;
                    switch (count) {
                        case 1:
                            tV_ThisOver1.setText(ones);
                            break;
                        case 2:
                            tV_ThisOver2.setText(ones);
                            break;
                        case 3:
                            tV_ThisOver3.setText(ones);
                            break;
                        case 4:
                            tV_ThisOver4.setText(ones);
                            break;
                        case 5:
                            tV_ThisOver5.setText(ones);
                            break;
                        case 6:
                            tV_ThisOver6.setText(ones);
                            break;
                        case 7:
                            tV_ThisOver7.setText(ones);
                            break;
                        case 8:
                            tV_ThisOver8.setText(ones);
                            break;
                        case 9:
                            tV_ThisOver9.setText(ones);
                            break;

                    }
                    if(ball==0)
                    {
                        count=0;
                    }
                    if (wicket == 10) {
                        Toast.makeText(Admin.this,"1st INNING OVER",Toast.LENGTH_LONG).show();
                        inning = 2;
                        run = 0;
                        ball = 0;
                        over = 0;
                        over1 = 0;
                        crr = 0;
                        wicket = 0;
                        batFrun = 0;
                        batSrun = 0;
                        batFBall = 0;
                        batSBall = 0;
                        batFSix = 0;
                        batSSix = 0;
                        batFFour = 0;
                        batSFour = 0;
                        batFSR = 0;
                        batSSR = 0;
                        bowlrun = 0;
                        bowlwicket = 0;
                        bowlmaiden = 0;
                        bowlover1 = 0;
                        bowlball = 0;
                        bowlballT = 0;
                        bowlover = 0;
                        bowlER = 0;
                        strike = "*";
                        nstrike = " ";
                        flag = true;
                        pshipr = 0;
                        pshipb = 0;
                        count = 0;

                        tV_Run.setText(" ");
                        tV_Over.setText(" ");
                        tV_Crr.setText(" ");
                        tV_wicket.setText(" ");
                        tV_FBatRun.setText(" ");
                        tV_FBatBall.setText(" ");
                        tV_FBatSR.setText(" ");
                        tV_SBatRun.setText(" ");
                        tV_SBatBall.setText(" ");
                        tV_SBatSR.setText(" ");
                        tV_BowlOvers.setText(" ");
                        tV_BowlMaiden.setText(" ");
                        tV_BowlRun.setText(" ");
                        tV_BowlWicket.setText(" ");
                        tV_BowlER.setText(" ");
                        tV_FBatFour.setText(" ");
                        tV_SBatFour.setText(" ");
                        tV_FBatSix.setText(" ");
                        tV_SBatSix.setText(" ");
                        tV_Pshipr.setText(" ");
                        tV_Pshipb.setText(" ");
                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                        tV_Inning.setText(Integer.toString(inning));
                        tV_Teamname.setText(vistorname1);
                    }


                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_FBatRun.setText(Integer.toString(batFrun));
                    tV_FBatBall.setText(Integer.toString(batFBall));
                    tV_FBatSR.setText(Double.toString(batFSR));
                    tV_SBatRun.setText(Integer.toString(batSrun));
                    tV_SBatBall.setText(Integer.toString(batSBall));
                    tV_SBatSR.setText(Double.toString(batSSR));
                    tV_BowlOvers.setText(Double.toString(bowlover));
                    tV_BowlMaiden.setText(Integer.toString(bowlmaiden));
                    tV_BowlRun.setText(Integer.toString(bowlrun));
                    tV_BowlWicket.setText(Integer.toString(bowlwicket));
                    tV_BowlER.setText(Double.toString(bowlER));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));


                } else {
                    inning = 2;
                    run = 0;
                    ball = 0;
                    over = 0;
                    over1 = 0;
                    crr = 0;
                    wicket = 0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun = 0;
                    bowlwicket = 0;
                    bowlmaiden = 0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER = 0;
                    strike = "*";
                    nstrike = " ";
                    flag = true;
                    pshipr = 0;
                    pshipb = 0;
                    count = 0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
            }
        });


        Button clearBtn = (Button) findViewById(R.id.ButtonClear);
        clearBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent =(TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent =(TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun =(TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun =(TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall =(TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall =(TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR =(TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR =(TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers =(TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden =(TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun =(TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket =(TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER =(TextView) findViewById(R.id.tVBowlER);
                TextView tV_FBatFour =(TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour =(TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSix =(TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix =(TextView) findViewById(R.id.tVSBatSix);
                TextView tV_Pshipr=(TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb=(TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1=(TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2=(TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3=(TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4=(TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5=(TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6=(TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7=(TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8=(TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9=(TextView) findViewById(R.id.tVThisOver9);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);


                run =0;
                ball =0;
                over =0;
                over1 =0;
                crr =0;
                wicket =0;
                batFrun = 0;
                batSrun = 0;
                batFBall = 0;
                batSBall = 0;
                batFSix = 0;
                batSSix = 0;
                batFFour = 0;
                batSFour = 0;
                batFSR = 0;
                batSSR = 0;
                bowlrun =0;
                bowlwicket =0;
                bowlmaiden =0;
                bowlover1 = 0;
                bowlball = 0;
                bowlballT = 0;
                bowlover = 0;
                bowlER=0;
                strike ="*";
                nstrike =" ";
                flag=true;
                pshipr=0;
                pshipb=0;
                count=0;


                tV_Run.setText(" ");
                tV_Over.setText(" ");
                tV_Crr.setText(" ");
                tV_wicket.setText(" ");
                tV_FBatRun.setText(" ");
                tV_FBatBall.setText(" ");
                tV_FBatSR.setText(" ");
                tV_SBatRun.setText(" ");
                tV_SBatBall.setText(" ");
                tV_SBatSR.setText(" ");
                tV_BowlOvers.setText(" ");
                tV_BowlMaiden.setText(" ");
                tV_BowlRun.setText(" ");
                tV_BowlWicket.setText(" ");
                tV_BowlER.setText(" ");
                tV_FBatFour.setText(" ");
                tV_SBatFour.setText(" ");
                tV_FBatSix.setText(" ");
                tV_SBatSix.setText(" ");
                tV_Pshipr.setText(" ");
                tV_Pshipb.setText(" ");
                tV_ThisOver1.setText(" ");
                tV_ThisOver2.setText(" ");
                tV_ThisOver3.setText(" ");
                tV_ThisOver4.setText(" ");
                tV_ThisOver5.setText(" ");
                tV_ThisOver6.setText(" ");
                tV_ThisOver7.setText(" ");
                tV_ThisOver8.setText(" ");
                tV_ThisOver9.setText(" ");


            }
        });

       Button noballBtn = (Button) findViewById(R.id.ButtonNoBall);
        noballBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent =(TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent =(TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun =(TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun =(TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall =(TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall =(TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR =(TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR =(TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers =(TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden =(TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun =(TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket =(TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER =(TextView) findViewById(R.id.tVBowlER);
                TextView tV_Pshipr=(TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb=(TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1=(TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2=(TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3=(TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4=(TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5=(TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6=(TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7=(TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8=(TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9=(TextView) findViewById(R.id.tVThisOver9);
                TextView tV_FBatFour = (TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour = (TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSix = (TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix = (TextView) findViewById(R.id.tVSBatSix);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);
                if(over!=inputOver)
                {
                if(count==0 || count==9)
                {
                count=0;

                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                }


                    tV_Over.setText(Double.toString(over));
                    tV_FBatBall.setText(Integer.toString(batFBall));
                    tV_SBatBall.setText(Integer.toString(batSBall));
                    tV_BowlOvers.setText(Double.toString(bowlover));
                    tV_Pshipb.setText(Integer.toString(pshipb));
                ones="N";
                count+=1;
                run += 1;
                pshipr+=1;
                pshipb-=1;
                if(ball==0 && bowlball==0)
                {
                    ball=0.5;
                    over1-=1;
                    over-=0.5;
                    bowlball=0.5;
                    bowlover1-=1;
                    bowlover-=0.5;
                    crr = 6.0 * run / ballT ;
                    bowlER = 6.0 * run / ballT;

                }
                else
                {
                    ball -= 0.1;
                    ballT -= 1;
                    if(ball == 0.6)
                    {
                        over1 += 1;
                        ball = 0;
                    }
                    over = over1 + ball;
                    crr = 6.0 * run / ballT ;

                    bowlball -= 0.1;
                    bowlballT -= 1;
                    if(bowlball == 0.6)
                    {
                        bowlover1 += 1;
                        bowlball = 0;
                    }
                    bowlover = bowlover1 + bowlball;
                    bowlER = 6.0 * run / ballT;
                }
                switch (count)
                {
                    case 1:tV_ThisOver1.setText(ones);break;
                    case 2:tV_ThisOver2.setText(ones);break;
                    case 3:tV_ThisOver3.setText(ones);break;
                    case 4:tV_ThisOver4.setText(ones);break;
                    case 5:tV_ThisOver5.setText(ones);break;
                    case 6:tV_ThisOver6.setText(ones);break;
                    case 7:tV_ThisOver7.setText(ones);break;
                    case 8:tV_ThisOver8.setText(ones);break;
                    case 9:tV_ThisOver9.setText(ones);break;

                }
                 if(ball==0)
                    {
                        count=0;
                    }


                tV_Run.setText(Integer.toString(run));

                tV_Crr.setText(Double.toString(crr));
                tV_wicket.setText(Integer.toString(wicket));
                tV_FBatRun.setText(Integer.toString(batFrun));

                tV_FBatSR.setText(Double.toString(batFSR));
                tV_SBatRun.setText(Integer.toString(batSrun));

                tV_SBatSR.setText(Double.toString(batSSR));

                tV_BowlMaiden.setText(Integer.toString(bowlmaiden));
                tV_BowlRun.setText(Integer.toString(bowlrun));
                tV_BowlWicket.setText(Integer.toString(bowlwicket));
                tV_BowlER.setText(Double.toString(bowlER));
                tV_Pshipr.setText(Integer.toString(pshipr));




            }
            else {
                    inning = 2;
                    run = 0;
                    ball = 0;
                    over = 0;
                    over1 = 0;
                    crr = 0;
                    wicket = 0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun = 0;
                    bowlwicket = 0;
                    bowlmaiden = 0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER = 0;
                    strike = "*";
                    nstrike = " ";
                    flag = true;
                    pshipr = 0;
                    pshipb = 0;
                    count = 0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
                }
        });

        Button byesBtn = (Button) findViewById(R.id.ButtonByes);
        byesBtn.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {


                TextView tV_Run = (TextView) findViewById(R.id.tVRun);
                TextView tV_Over = (TextView) findViewById(R.id.tVOver);
                TextView tV_Crr = (TextView) findViewById(R.id.tvCrr);
                TextView tV_wicket = (TextView) findViewById(R.id.tVWicket);
                TextView tV_FBatCurrent =(TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatCurrent =(TextView) findViewById(R.id.tVSBatStrike);
                TextView tV_FBatRun =(TextView) findViewById(R.id.tVFBatRun);
                TextView tV_SBatRun =(TextView) findViewById(R.id.tVSBatRun);
                TextView tV_FBatBall =(TextView) findViewById(R.id.tVFBatBall);
                TextView tV_SBatBall =(TextView) findViewById(R.id.tVSBatBall);
                TextView tV_FBatSR =(TextView) findViewById(R.id.tVFBatSR);
                TextView tV_SBatSR =(TextView) findViewById(R.id.tVSBatSR);
                TextView tV_BowlOvers =(TextView) findViewById(R.id.tVBowlOvers);
                TextView tV_BowlMaiden =(TextView) findViewById(R.id.tVBowlMaiden);
                TextView tV_BowlRun =(TextView) findViewById(R.id.tVBowlRun);
                TextView tV_BowlWicket =(TextView) findViewById(R.id.tVBowlWicket);
                TextView tV_BowlER =(TextView) findViewById(R.id.tVBowlER);
                TextView tV_FBatFour =(TextView) findViewById(R.id.tVFBatFour);
                TextView tV_SBatFour =(TextView) findViewById(R.id.tVSBatFour);
                TextView tV_FBatSix =(TextView) findViewById(R.id.tVFBatSix);
                TextView tV_SBatSix =(TextView) findViewById(R.id.tVSBatSix);
                TextView tV_Pshipr=(TextView) findViewById(R.id.tVPshipR);
                TextView tV_Pshipb=(TextView) findViewById(R.id.tVPshipB);
                TextView tV_ThisOver1=(TextView) findViewById(R.id.tVThisOver1);
                TextView tV_ThisOver2=(TextView) findViewById(R.id.tVThisOver2);
                TextView tV_ThisOver3=(TextView) findViewById(R.id.tVThisOver3);
                TextView tV_ThisOver4=(TextView) findViewById(R.id.tVThisOver4);
                TextView tV_ThisOver5=(TextView) findViewById(R.id.tVThisOver5);
                TextView tV_ThisOver6=(TextView) findViewById(R.id.tVThisOver6);
                TextView tV_ThisOver7=(TextView) findViewById(R.id.tVThisOver7);
                TextView tV_ThisOver8=(TextView) findViewById(R.id.tVThisOver8);
                TextView tV_ThisOver9=(TextView) findViewById(R.id.tVThisOver9);
                TextView tV_Inning = (TextView) findViewById(R.id.tvInning);
                TextView tV_Teamname = (TextView) findViewById(R.id.tvteamname);
                EditText eT_Byes=(EditText) findViewById(R.id.eTByes);
                if (over != inputOver) {
                    if (count == 0 || count == 9) {
                        count=0;

                        tV_ThisOver1.setText(" ");
                        tV_ThisOver2.setText(" ");
                        tV_ThisOver3.setText(" ");
                        tV_ThisOver4.setText(" ");
                        tV_ThisOver5.setText(" ");
                        tV_ThisOver6.setText(" ");
                        tV_ThisOver7.setText(" ");
                        tV_ThisOver8.setText(" ");
                        tV_ThisOver9.setText(" ");
                    }

                    int byes = Integer.parseInt(eT_Byes.getText().toString());


                    String onebyes = Integer.toString(byes);
                    ones = "B".concat(onebyes);
                    run += byes;
                    ball += 0.1;
                    count += 1;
                    if (ball == 0.6) {
                        over1 += 1;
                        ball = 0;
                    }
                    over = over1 + ball;
                    crr = 6.0 * run / ballT;
                    pshipr += byes;
                    pshipb += 1;

                    switch (count) {
                        case 1:
                            tV_ThisOver1.setText(ones);
                            break;
                        case 2:
                            tV_ThisOver2.setText(ones);
                            break;
                        case 3:
                            tV_ThisOver3.setText(ones);
                            break;
                        case 4:
                            tV_ThisOver4.setText(ones);
                            break;
                        case 5:
                            tV_ThisOver5.setText(ones);
                            break;
                        case 6:
                            tV_ThisOver6.setText(ones);
                            break;
                        case 7:
                            tV_ThisOver7.setText(ones);
                            break;
                        case 8:
                            tV_ThisOver8.setText(ones);
                            break;
                        case 9:
                            tV_ThisOver9.setText(ones);
                            break;

                    }
                    if(ball==0)
                    {
                        count=0;
                    }

                    tV_Run.setText(Integer.toString(run));
                    tV_Over.setText(Double.toString(over));
                    tV_Crr.setText(Double.toString(crr));
                    tV_wicket.setText(Integer.toString(wicket));
                    tV_Pshipr.setText(Integer.toString(pshipr));
                    tV_Pshipb.setText(Integer.toString(pshipb));


                } else {
                    Toast.makeText(Admin.this,"1st INNING OVER",Toast.LENGTH_LONG).show();
                    inning = 2;
                    run = 0;
                    ball = 0;
                    over = 0;
                    over1 = 0;
                    crr = 0;
                    wicket = 0;
                    batFrun = 0;
                    batSrun = 0;
                    batFBall = 0;
                    batSBall = 0;
                    batFSix = 0;
                    batSSix = 0;
                    batFFour = 0;
                    batSFour = 0;
                    batFSR = 0;
                    batSSR = 0;
                    bowlrun = 0;
                    bowlwicket = 0;
                    bowlmaiden = 0;
                    bowlover1 = 0;
                    bowlball = 0;
                    bowlballT = 0;
                    bowlover = 0;
                    bowlER = 0;
                    strike = "*";
                    nstrike = " ";
                    flag = true;
                    pshipr = 0;
                    pshipb = 0;
                    count = 0;

                    tV_Run.setText(" ");
                    tV_Over.setText(" ");
                    tV_Crr.setText(" ");
                    tV_wicket.setText(" ");
                    tV_FBatRun.setText(" ");
                    tV_FBatBall.setText(" ");
                    tV_FBatSR.setText(" ");
                    tV_SBatRun.setText(" ");
                    tV_SBatBall.setText(" ");
                    tV_SBatSR.setText(" ");
                    tV_BowlOvers.setText(" ");
                    tV_BowlMaiden.setText(" ");
                    tV_BowlRun.setText(" ");
                    tV_BowlWicket.setText(" ");
                    tV_BowlER.setText(" ");
                    tV_FBatFour.setText(" ");
                    tV_SBatFour.setText(" ");
                    tV_FBatSix.setText(" ");
                    tV_SBatSix.setText(" ");
                    tV_Pshipr.setText(" ");
                    tV_Pshipb.setText(" ");
                    tV_ThisOver1.setText(" ");
                    tV_ThisOver2.setText(" ");
                    tV_ThisOver3.setText(" ");
                    tV_ThisOver4.setText(" ");
                    tV_ThisOver5.setText(" ");
                    tV_ThisOver6.setText(" ");
                    tV_ThisOver7.setText(" ");
                    tV_ThisOver8.setText(" ");
                    tV_ThisOver9.setText(" ");
                    tV_Inning.setText(Integer.toString(inning));
                    tV_Teamname.setText(vistorname1);
                }
            }
        });

        Button swapBtn = (Button) findViewById(R.id.ButtonSwap);
        swapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                TextView tV_FBatStrike =(TextView) findViewById(R.id.tVFBatStrike);
                TextView tV_SBatStrike =(TextView) findViewById(R.id.tVSBatStrike);



                if(flag==true)
                {
                    tV_FBatStrike.setText(nstrike);
                    tV_SBatStrike.setText(strike);
                    flag=false;

                }

                else
                {
                    tV_FBatStrike.setText(strike);
                    tV_SBatStrike.setText(nstrike);
                    flag=true;
                }

            }
        });



    }
}
