package com.example.cricify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MATCHCODE extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matchcode);
    }

    public void btnSubmit(View view) {
        Intent Submitintent = new Intent(this, USERPAGE.class);
        startActivity(Submitintent);
    }
}