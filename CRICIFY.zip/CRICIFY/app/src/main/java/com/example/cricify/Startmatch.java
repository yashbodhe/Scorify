package com.example.cricify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

public class Startmatch extends AppCompatActivity {
    static int toss=1;
    static int opted=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_startmatch);


    }
    public void btnContinue(View view)
    {
        EditText eT_HostTeam=(EditText) findViewById(R.id.eTHostTeam);
        EditText eT_vistorTeam=(EditText) findViewById(R.id.eTVistorTeam);
        EditText eT_Overs=(EditText) findViewById(R.id.eTOvers);
        Intent adminintent=new Intent(this,Playername.class);

        if(toss==1&&opted==1 || toss==0&&opted==0)
        {
            adminintent.putExtra("HT", eT_HostTeam.getText().toString());
            adminintent.putExtra("VT", eT_vistorTeam.getText().toString());
        }
        if(toss==1&&opted==0 || toss==0&&opted==1)
        {
            adminintent.putExtra("HT", eT_vistorTeam.getText().toString());
            adminintent.putExtra("VT", eT_HostTeam.getText().toString());
        }
            adminintent.putExtra("O", eT_Overs.getText().toString());
            startActivity(adminintent);

    }
    public void onRadioButtonClicked(View view)
    {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.rBtnHostTeam:
                if (checked)
                    // Pirates are the best
                    toss = 1;
                break;
            case R.id.rBtnVistorTeam:
                if (checked)
                    // Ninjas rule
                    toss = 0;
                break;
        }

    }
    public void onRadioButtonClicked1(View view)
    {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.rBtnBat:
                if (checked)
                    // Pirates are the best
                    opted = 1;
                break;
            case R.id.rBtnBowl:
                if (checked)
                    // Ninjas rule
                    opted= 0;
                break;
        }

    }

    public void btnMatchCode(View view)
    {
        Intent matchcodeintent=new Intent(this,MATCHCODE.class);
        startActivity(matchcodeintent);
    }
    public void btnHistory(View view)
    {
        Intent historyintent=new Intent(this,HISTORY.class);
        startActivity(historyintent);
    }
}
